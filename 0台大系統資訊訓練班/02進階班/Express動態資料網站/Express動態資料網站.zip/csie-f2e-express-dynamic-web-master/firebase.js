// 初始化firebase
// FIREBASE NODE.JS初始化文件
// https://firebase.google.com/docs/admin/setup

// TODO: 初始化FIREBASE

// 輸出 admin 供其他檔案使用
module.exports = admin;